<?php get_header();?>
    <br>
    <?php
        if(have_posts()){
            while(have_posts()){
                the_post();
    ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="jumbotron">
                            <br>
                            <h2 id="titulo"><?php the_title(); ?> </h2>
                            <br>
                        </div>
                    </div>
                </div>
             <fieldset id="three">
                <div class="row">
                    <div class"col-md-12">
                        <h6> <?php the_content(); ?> </h6>
                    </div>
                </div>
            </fieldset>
            <br>
            <br>
            <br>
    <?php
            }
        }
    ?> 
<?php get_footer();?>