<?php

add_theme_suport('post-thumbnails');

?>