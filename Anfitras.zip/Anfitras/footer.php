
	

	<div class="row" id="footer">
		<div class="col-md-12 rodape">
			<p class="feito ">Feito pelo Anfitras</p>
		</div>
	</div>
	

	<?php wp_footer(); ?>



</body>
</html>